@extends('layout')
@section('title', 'Academic Records Request System - Dashboard')
@section('content')
<div class="container">
    {{-- CHARLES PLS EDIT --}}
</div>
@endsection