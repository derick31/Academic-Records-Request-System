@extends('layout')
@section('title', 'Academic Records Request System - Edit Account')
@section('content')
<div class="container">
    {{-- CHARLES PLS EDIT --}}
</div>
@endsection